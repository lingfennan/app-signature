package org.codeandmagic.deferredobject.android;

public class HttpProgress {

}
