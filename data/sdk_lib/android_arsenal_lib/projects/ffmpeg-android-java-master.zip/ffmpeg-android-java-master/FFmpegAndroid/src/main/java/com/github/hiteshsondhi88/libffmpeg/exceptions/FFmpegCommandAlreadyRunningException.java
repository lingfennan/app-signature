package com.github.hiteshsondhi88.libffmpeg.exceptions;

public class FFmpegCommandAlreadyRunningException extends Exception {

    public FFmpegCommandAlreadyRunningException(String message) {
        super(message);
    }

}
