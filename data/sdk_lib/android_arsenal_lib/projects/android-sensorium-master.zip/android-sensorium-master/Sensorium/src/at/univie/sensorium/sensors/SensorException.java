package at.univie.sensorium.sensors;

public class SensorException extends Exception {

	private static final long serialVersionUID = 7394491230462782761L;

	public SensorException(String cause){
		super(cause);
	}
}
