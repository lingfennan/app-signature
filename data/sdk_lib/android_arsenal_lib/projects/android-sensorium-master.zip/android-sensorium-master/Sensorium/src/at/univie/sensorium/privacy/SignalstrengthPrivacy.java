package at.univie.sensorium.privacy;

public class SignalstrengthPrivacy {

}
