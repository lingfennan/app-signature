ILog
====

Simple Logging Tool for Android and Java Platforms

Download
========
Jar file download https://github.com/MoshDev/ILog/releases/tag/Version_0.1

Samples and documentation
=========================

    new ILog().d(); // as simple as that

Refer to http://moshx.com/?p=57  for more details
