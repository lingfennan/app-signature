/**
 * Contains classes for multidimensional access of arrays and buffers.
 */
package org.bytedeco.javacpp.indexer;
