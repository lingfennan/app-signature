package me.cosmodro.app.rhombus;

public enum MessageType {
	NO_DATA_PRESENT,
	DATA_PRESENT,
	RECORDING_ERROR,
	INVALID_SAMPLE_RATE,
	DATA
}
