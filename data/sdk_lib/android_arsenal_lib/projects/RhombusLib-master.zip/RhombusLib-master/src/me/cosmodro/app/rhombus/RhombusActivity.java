package me.cosmodro.app.rhombus;

public interface RhombusActivity {

	public void setDongleReady(boolean state);
	
}
